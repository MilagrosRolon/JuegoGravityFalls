package io.github.accesoriosB2Mapa;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.World;

import io.github.pantallas.PantallaEmpezarBusqueda;


public class Roca extends SpritesTiledInteractivos {
	public Roca(PantallaEmpezarBusqueda screen, Rectangle bounds) {
		super(screen, bounds);

	}
}
