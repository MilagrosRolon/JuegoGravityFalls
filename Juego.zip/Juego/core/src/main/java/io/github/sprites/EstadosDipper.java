package io.github.sprites;

public enum EstadosDipper {

	CAYENDO, SALTANDO, PARADO, CORRIENDO;
}
