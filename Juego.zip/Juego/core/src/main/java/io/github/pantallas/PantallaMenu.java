package io.github.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;

import io.github.elementos.Imagen;
import io.github.elementos.Musica;
import io.github.elementos.Texto;
import io.github.entradasSalidas.EntradasSalidas;
import io.github.juego.GravityFalls;
import io.github.utiles.Config;
import io.github.utiles.Recursos;
import io.github.utiles.Render;

public class PantallaMenu implements Screen {

	private Imagen fondo;
	private EntradasSalidas entradas;
	private GravityFalls game;
	// TEXTO
	private Texto opciones[] = new Texto[3];
	private String textos[] = { "EMPEZAR BUSQUEDA", "COMO JUGAR", "CERRAR" };
	private int opcion = 1;
	public float tiempo = 0;
	// MUSICA
	private Imagen iconoMusica;
	private Musica sonido;
	private boolean encendido = true;

	public PantallaMenu(GravityFalls game) {
		this.game = game;
	}

	@Override
	public void show() {
		fondo = new Imagen(Recursos.MENU);
		entradas = new EntradasSalidas(this);
		this.sonido = new Musica(Render.manager);
		sonido.setEntradasSalidas(entradas);
		Gdx.input.setInputProcessor(entradas);
		// Mostrar musica (icono y sonido)
		iconoMusica = new Imagen(Recursos.MUSICAPRENDIDA);
		sonido.mostrarIcono(iconoMusica);
		sonido.sonarMusica(Recursos.MUSICA);
		// Mostrar texto
		int avance = 35;
		for (int i = 0; i < opciones.length; i++) {
			opciones[i] = new Texto(Recursos.FUENTE, 35, Color.WHITE, true);
			opciones[i].setTexto(textos[i]);
			opciones[i].setPosition((Config.ANCHO / 2) - (opciones[i].getAncho() / 2),
					((Config.ALTO / 2) + (opciones[0].getAlto() / 2)) - ((opciones[i].getAlto() * i) + (i * avance)));
		}

	}
	@Override
	public void render(float delta) {
	    tiempo += delta;

	    Render.limpiarPantalla(0, 0, 0);

	    // Manejo de teclas primero
	    if (entradas.isAbajo() && tiempo > 0.09f) {
	        opcion++;
	        if (opcion > opciones.length) {
	            opcion = 1;
	        }
	        tiempo = 0;
	    } else if (entradas.isArriba() && tiempo > 0.09f) {
	        opcion--;
	        if (opcion < 1) {
	            opcion = opciones.length;
	        }
	        tiempo = 0;
	    }

	    // Navegar con el ratón solo cuando no haya tecla presionada
	    if (!entradas.isAbajo() && !entradas.isArriba()) {
	        for (int i = 0; i < opciones.length; i++) {
	            if (entradas.getMouseX() >= opciones[i].getX()
	                    && entradas.getMouseX() <= opciones[i].getX() + opciones[i].getAncho()
	                    && entradas.getMouseY() >= opciones[i].getY() - opciones[i].getAlto()
	                    && entradas.getMouseY() <= opciones[i].getY()) {
	                opcion = i + 1;
	            }
	        }
	    }

	    // Actualización del color de las opciones
	    for (int i = 0; i < opciones.length; i++) {
	        if (i == opcion - 1) {
	            opciones[i].setColor(Color.VIOLET);
	        } else {
	            opciones[i].setColor(Color.WHITE);
	        }
	    }
	    
		
		// Ajuste visual
				opcion = sonido.delimitarMouse(iconoMusica, opcion);

	    Render.batch.begin();
	    fondo.dibujar();
	    iconoMusica.dibujar();
	    for (int i = 0; i < opciones.length; i++) {
	        opciones[i].dibujar();
	    }
	    Render.batch.end();

	    // Acción de selección
	    if ((entradas.isEnter() || entradas.isClick()) && opcion != -1) {
	        switch (opcion) {
	            case 1:
	                game.setScreen(new PantallaElegirPersonaje(game));
	                break;
	            case 2:
	                game.setScreen(new PantallaReglas(game));
	                break;
	            case 3:
	                Gdx.app.exit();
	                break;
	            case 4:
	                iconoMusica = sonido.pausarMusica(encendido, iconoMusica);
	                encendido = !encendido;
	                break;
	        }
	        entradas.resetInputs(); // Resetea las entradas para evitar múltiples ejecuciones con un solo clic o tecla
	    }
	}


	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void dispose() {
		fondo.dispose();
		iconoMusica.dispose();
		for (Texto opcion : opciones) {
			opcion.dispose();
		}
		sonido.dispose();
	}
}