package io.github.accesoriosB2Mapa;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.World;

import io.github.pantallas.PantallaEmpezarBusqueda;


public abstract class Enemy  extends Sprite {
    protected World world;
    protected PantallaEmpezarBusqueda screen;
    public Body b2body;
    
	public Enemy(PantallaEmpezarBusqueda screen , float  x, float y) {
		this.world = screen.getWorld();
		this.screen = screen;
		setPosition(x, y);
	}

	protected abstract void defineEnemy();
	
}


