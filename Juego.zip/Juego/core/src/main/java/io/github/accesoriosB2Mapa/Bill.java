package io.github.accesoriosB2Mapa;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;

import com.badlogic.gdx.utils.Array;

import io.github.juego.GravityFalls;
import io.github.pantallas.PantallaEmpezarBusqueda;
import io.github.sprites.Dipper;

public class Bill extends Enemy {

	private float stateTime;
	private Animation walkAnimation;
	private Array<TextureRegion> frames;

	public Bill(PantallaEmpezarBusqueda screen, float x, float y) {
		super(screen, x, y);
//		frames = new Array<TextureRegion>();
//		for (int i = 0; i < 2; i++) {
//			frames.add(new TextureRegion(screen.getAtlas().findRegion("bill_derecha"), i * 16, 0, 16, 16));
//			walkAnimation = new Animation(0.4f, frames);
//			stateTime = 0;
////			setBounds(getX(), getY(), 16 / Dipper.PPM, 16 / Dipper.PPM);
//		}

	}

	protected void defineEnemy() {
//		BodyDef bDef = new BodyDef();
//		bDef.position.set(32 / GravityFalls.PPM, 180 / GravityFalls.PPM); // Posición inicial en el mapa
//		bDef.type = BodyDef.BodyType.DynamicBody; // Tipo de cuerpo dinámico
//		b2body = world.createBody(bDef); // Crea el cuerpo físico en el mundo
//
//		// Define las propiedades físicas del cuerpo
//		FixtureDef fDef = new FixtureDef();
//		CircleShape shape = new CircleShape();
//		shape.setRadius(6 / Dipper.PPM); // Crea un rectángulo como cuerpo
//		fDef.filter.categoryBits = Dipper.ENEMY_BIT;
//		fDef.filter.categoryBits = Dipper.SUELO_BIT |
//
//				Dipper.LIBRO_BIT | Dipper.PIEDRA_BIT | Dipper.ENEMY_BIT | Dipper.DIPPER_BIT;
//
//		fDef.shape = shape;
//		b2body.createFixture(fDef); // Crea el fixture en el cuerpo

	}


	public void update(float dt) {
//		stateTime += dt;
//		setPosition(b2body.getPosition().x - getWidth() / 2, b2body.getPosition().y - getHeight() / 2);
////		setRegion(walkAnimation.getKeyFrame(stateTime, true));

	}



}
