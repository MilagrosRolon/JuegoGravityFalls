package io.github.sprites;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.EdgeShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import io.github.juego.GravityFalls;
import io.github.pantallas.PantallaEmpezarBusqueda;

public class Dipper extends Sprite {
	public static final short LIBRO_BIT = 2;  
	public static final short SUELO_BIT = 1;
	public static final short PIEDRA_BIT = 4 ;
	public static final short ENEMY_BIT = 64;
	public static final short DESTROYED_BIT = 16; 
	public static final short DIPPER_BIT = 2; 
  
	public static float PPM;
	public World world;
	public Body b2Body;
	public EstadosDipper estadoActual;
	public EstadosDipper estadoAnterior;
	private Animation<TextureRegion> dipperCorre;
	private Animation<TextureRegion> dipperSalta;
	private TextureRegion dipperParado;
	private float temporizadorEstado;
	private boolean corriendoDerecha;
	private Game game;
	private int librosRecogidos;
	private int saltosExtras;
	private static final int MAX_SALTOS_EXTRAS = 2;

	public Dipper(PantallaEmpezarBusqueda screen, GravityFalls game) {
	    super();
	    this.game = game; 
	    
		// Cargar el atlas
		TextureAtlas atlas = screen.getAtlas();
		if (atlas == null) {
			System.out.println("Atlas no encontrado.");
			throw new RuntimeException("No se pudo cargar el atlas.");
		}

		// Inicializar las regiones
		TextureRegion region = atlas.findRegion("dipper_parado-removebg-preview");
		if (region == null) {
			System.out.println("Región 'dipper_parado-removebg-preview' no encontrada.");
			throw new RuntimeException("No se pudo encontrar la región en el atlas.");
		}
		this.world = screen.getWorld();
		estadoActual = EstadosDipper.PARADO;
		estadoAnterior = EstadosDipper.PARADO;
		temporizadorEstado = 0;
		corriendoDerecha = true;

		// Configura la región y el tamaño del Sprite
		setRegion(region);
		float scaleFactor = 0.20f;
		setBounds(0, 0, (region.getRegionWidth() / GravityFalls.PPM) * scaleFactor,
				(region.getRegionHeight() / GravityFalls.PPM) * scaleFactor);

		defineDipper();

		// animaciones
		Array<TextureRegion> frames = new Array<TextureRegion>();
		for (int i = 1; i < 6; i++) {
			frames.add(atlas.findRegion("dipper_camina" + i + "-removebg-preview"));
		}
		dipperCorre = new Animation<>(0.1f, frames);
		frames.clear();
		for (int i = 4; i < 5; i++) {
			frames.add(atlas.findRegion("dipper_salta" + i + "-removebg-preview"));
		}
		dipperSalta = new Animation<>(0.1f, frames);

		dipperParado = atlas.findRegion("dipper_parado-removebg-preview");
	}

	public int getLibros() {
		return librosRecogidos;
	}
	
	public void saltar() {
	    if (b2Body.getLinearVelocity().y == 0) { // Dipper está en el suelo
	        b2Body.applyLinearImpulse(new Vector2(0, 6.0f), b2Body.getWorldCenter(), true); // Salto inicial
	        saltosExtras = 0; // Reinicia el contador de saltos extra
	    } else if (saltosExtras < MAX_SALTOS_EXTRAS) { // Permitir saltos extra si no alcanzó el máximo
	        b2Body.applyLinearImpulse(new Vector2(0, 4.0f), b2Body.getWorldCenter(), true); // Impulso extra
	        saltosExtras++; // Incrementa el contador
	    }
	}


	public void update(float dt) {
		setPosition(b2Body.getPosition().x - getWidth() / 2, b2Body.getPosition().y - getHeight() / 2.5f);
		setRegion(getFrame(dt));

		// Verifica si dipper ha caído fuera del área visible
		if (b2Body.getPosition().y < -10 / GravityFalls.PPM) { 
			System.out.println("Game Over!");
			((PantallaEmpezarBusqueda) game.getScreen()).gameOver();
		}
		
		 // Resetea los saltos extra al tocar el suelo
	    if (b2Body.getLinearVelocity().y == 0) {
	        saltosExtras = 0;
	    }
	}

	public TextureRegion getFrame(float dt) {
		estadoActual = getEstado();
		TextureRegion region;

		switch (estadoActual) {
		case SALTANDO:
			region = dipperSalta.getKeyFrame(temporizadorEstado);
			break;
		case CORRIENDO:
			region = dipperCorre.getKeyFrame(temporizadorEstado, true);
			break;
		case CAYENDO:
		case PARADO:
		default:
			region = dipperParado;
			break;
		}

		if ((b2Body.getLinearVelocity().x < 0 || !corriendoDerecha) && !region.isFlipX()) {
			region.flip(true, false);
			corriendoDerecha = true;
		} else if ((b2Body.getLinearVelocity().x > 0 || !corriendoDerecha) && region.isFlipX()) {
			region.flip(true, false);
			corriendoDerecha = true;
		}

		temporizadorEstado = estadoActual == estadoAnterior ? temporizadorEstado + dt : 0;
		estadoAnterior = estadoActual;
		return region;
	}

	public EstadosDipper getEstado() {
		if (b2Body.getLinearVelocity().y > 0
				|| (b2Body.getLinearVelocity().y < 0 && estadoAnterior == EstadosDipper.SALTANDO)) {
			return EstadosDipper.SALTANDO;
		} else if (b2Body.getLinearVelocity().y < 0) {
			return EstadosDipper.CAYENDO;
		} else if (b2Body.getLinearVelocity().x != 0) {
			return EstadosDipper.CORRIENDO;
		} else {
			return EstadosDipper.PARADO;
		}
	}
	

	public void defineDipper() {
	    // Define las propiedades del cuerpo
	    BodyDef bDef = new BodyDef();
	    bDef.position.set(32 / GravityFalls.PPM, 180 / GravityFalls.PPM); // Posición inicial en el mapa
	    bDef.type = BodyDef.BodyType.DynamicBody; // Tipo de cuerpo dinámico
	    bDef.fixedRotation = true; // Evita rotación del cuerpo
	    b2Body = world.createBody(bDef); // Crea el cuerpo físico en el mundo

	    // Define la forma del cuerpo principal
	    PolygonShape shape = new PolygonShape();
	    float width = 12 / GravityFalls.PPM;
	    float height = 26 / GravityFalls.PPM;
	    shape.setAsBox(width / 2, height / 2); // Crea un rectángulo como cuerpo

	    // Define las propiedades físicas del cuerpo
	    FixtureDef fDef = new FixtureDef();
	    fDef.density = 8.0f; // Densidad del cuerpo
	    fDef.friction = 0.5f; // Fricción (para movimientos en el suelo)
	    fDef.restitution = 0.05f; // Elasticidad (rebotes)
	    fDef.shape = shape; // Asocia la forma al fixture
	    b2Body.createFixture(fDef).setUserData(this); // Crea el fixture en el cuerpo

	    // Limpia la memoria de la forma
	    shape.dispose();

	    // Define la forma del sensor de la cabeza
	    EdgeShape head = new EdgeShape();
	    head.set(new Vector2(-width / 4, height / 2), new Vector2(width / 4, height / 2)); // Ajusta la posición del sensor

	    fDef.shape = head;
	    fDef.isSensor = true; // Marca este fixture como un sensor
	    b2Body.createFixture(fDef).setUserData("head"); // Asocia el sensor con la cadena "head"

	    // Limpia la memoria del sensor
	    head.dispose();
	}


}