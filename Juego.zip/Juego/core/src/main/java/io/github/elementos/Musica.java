package io.github.elementos;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;

import io.github.entradasSalidas.EntradasSalidas;
import io.github.utiles.Recursos;
import io.github.utiles.Render;


public class Musica {
	
	private Music musica;
	private AssetManager manager;
	private EntradasSalidas entradas;
	
	public Musica(AssetManager manager) {
        this.manager = manager;
    }

    public void setEntradasSalidas(EntradasSalidas entradas) {
        this.entradas = entradas;
    }
	public void disposeManager() {
		manager.dispose();
	}
	
	public void generarSonidoCaminar() {
		Render.manager.get(Recursos.CAMINAR, Sound.class).play();
	}
	
	public void generarSonidoSaltar() {
		Render.manager.get(Recursos.SALTAR, Sound.class).play();
	}

	public void mostrarIcono(Imagen iconoMusica) {
		iconoMusica.setSize(60, 60);
		iconoMusica.setPosition(1012, 565);
	}
	
	public void sonarMusica(String ruta) {
		musica = Render.manager.get(ruta, Music.class);
		musica.setLooping(true);
		musica.setVolume(0.03f);
		musica.play();
	}
	
	public Imagen pausarMusica(boolean encendido, Imagen iconoMusica) {
		if (encendido) {
			iconoMusica = new Imagen(Recursos.MUSICAPRENDIDA);
			mostrarIcono(iconoMusica);
            musica.play();
        } else {
        	iconoMusica = new Imagen(Recursos.MUSICAAPAGADA);
        	mostrarIcono(iconoMusica);
            musica.pause();
        }
		return iconoMusica;
	}
	
	public void dispose() {
		musica.dispose();
	}

	public int delimitarMouse(Imagen iconoMusica, int opcion) {
		if (entradas.getMouseX() >= iconoMusica.getX()
				&& entradas.getMouseX() <= iconoMusica.getX() + iconoMusica.getAncho()
				&& entradas.getMouseY() >= iconoMusica.getY() - iconoMusica.getAlto()
				&& entradas.getMouseY() <= iconoMusica.getY()) {
			opcion = 4;
		}
		return opcion;
	}
}
