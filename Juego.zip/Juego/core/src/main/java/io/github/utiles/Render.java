package io.github.utiles;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.juego.GravityFalls;

public class Render {
    public static SpriteBatch batch;
    public static AssetManager manager;
    public static GravityFalls app;

    public static void limpiarPantalla(float r, float g, float b) {
        Gdx.gl.glClearColor(r, g, b, 1); // Limpiar la imagen y definir el color (rojo, verde, azul, transparencia)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); // Limpiar el buffer de color
    }
    
    

    public static void initialize() {
        batch = new SpriteBatch();
    }

    public static void cargarRecursos() {
        manager = new AssetManager();
        manager.load(Recursos.MUSICA, Music.class);
        manager.load(Recursos.CAMINAR, Sound.class);
        manager.load(Recursos.SALTAR, Sound.class);
        // Cargar más recursos si es necesario
    }

    public static void admin() {
        cargarRecursos();

        // Esperar hasta que todos los recursos estén cargados
        while (!manager.update()) {
            float progress = manager.getProgress(); // Obtener el progreso de la carga
            Gdx.app.log("Carga", "Progreso de carga: " + progress * 100 + "%");
        }
    }

    public static void dispose() {
        batch.dispose();
        if (manager != null) {
            manager.dispose();
        }
    }
    public static SpriteBatch getBatch() {
        return batch;
    }

}
