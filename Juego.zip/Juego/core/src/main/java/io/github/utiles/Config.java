package io.github.utiles;

public class Config {
	
	public static final int ANCHO = 500;//1100
	public static final int ALTO = 350;//650

}
