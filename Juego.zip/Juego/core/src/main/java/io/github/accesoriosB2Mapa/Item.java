package io.github.accesoriosB2Mapa;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

import io.github.pantallas.PantallaEmpezarBusqueda;


public class Item extends objetosInteractivosTiled {
//
//	private TextureRegion libroTexture;
//	private boolean isDestroyed = false;

	public Item(PantallaEmpezarBusqueda screen, Rectangle bounds) {
		super(screen, bounds);
		fixture.setUserData(this);
	}

	@Override
	public void golpeCabeza() {

			Gdx.app.log("Item", "colision");	
	}



}
