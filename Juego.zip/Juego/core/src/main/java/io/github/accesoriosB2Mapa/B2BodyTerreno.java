package io.github.accesoriosB2Mapa;

import java.util.ArrayList;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.World;

import io.github.pantallas.PantallaEmpezarBusqueda;
import io.github.sprites.Dipper;


public class B2BodyTerreno {

    private World world;
    private TiledMap map;
    private ArrayList<Bill> bills;

    public B2BodyTerreno(PantallaEmpezarBusqueda screen) {
        this.world = screen.getWorld();
        this.map = screen.getMap();
        this.bills = new ArrayList<>();

        // Tierra
        for (MapObject object : map.getLayers().get(2).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            new Tierra(screen, rect);
        }

        // Roca
        for (MapObject object : map.getLayers().get(3).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            new Roca(screen, rect);
        }

        // Libro
     // En el ciclo que carga los libros en B2BodyTerreno
        for (MapObject object : map.getLayers().get(4).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            new Libro(screen, rect, "libro2");  // Aquí puedes cambiar el nombre del libro según sea necesario
        }


        // ContornoMapa
        for (MapObject object : map.getLayers().get(5).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            new ContornoMapa(screen, rect);
        }

        
        // Bills
        for (MapObject object : map.getLayers().get(6).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            bills.add(new Bill(screen, rect.getX() / Dipper.PPM, rect.getY() / Dipper.PPM));
        }
    }

    public ArrayList<Bill> getBills() {
        return bills;
    }
}
