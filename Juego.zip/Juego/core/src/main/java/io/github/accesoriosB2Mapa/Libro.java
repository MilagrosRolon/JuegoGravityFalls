package io.github.accesoriosB2Mapa;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

import io.github.pantallas.PantallaEmpezarBusqueda;


public class Libro extends SpritesTiledInteractivos {

	private TextureRegion libroTexture;
	private boolean isDestroyed = false;

	public Libro(PantallaEmpezarBusqueda screen, Rectangle bounds, String regionName) {
		super(screen, bounds);
	}



}
