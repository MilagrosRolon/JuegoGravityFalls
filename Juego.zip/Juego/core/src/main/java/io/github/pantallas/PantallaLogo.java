package io.github.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;

import io.github.elementos.Imagen;
import io.github.elementos.Texto;
import io.github.entradasSalidas.EntradasSalidas;
import io.github.juego.GravityFalls;
import io.github.utiles.Recursos;
import io.github.utiles.Render;


public class PantallaLogo implements Screen {

	private Label presEnterLabel;
	private Stage stage;
	Imagen fondo;
	SpriteBatch b;
	boolean efectoPantalla = false, termina = false;
	float a = 0;
	float efectoEspera = 0, contTiempo = 0;
	float efectoTermina = 1.0f, contTiempoTermina = 0;
	Texto t;
	EntradasSalidas entradasSalidas;
	private GravityFalls game;

	public PantallaLogo(GravityFalls game) {
		this.game = game;
	}

	@Override
	public void show() {
		
		stage = new Stage();
		entradasSalidas = new EntradasSalidas(this);
		Gdx.input.setInputProcessor(entradasSalidas);

		fondo = new Imagen(Recursos.LOGO);
		b = Render.batch;
		fondo.setTransparencia(0);

		// Crear y configurar la Label
		Label.LabelStyle labelStyle = new Label.LabelStyle();
		labelStyle.font = new BitmapFont();
		labelStyle.fontColor = Color.WHITE;
		presEnterLabel = new Label("( PRESIONA ENTER PARA SALTAR LA INTRO )", labelStyle);
		presEnterLabel.setFontScale(1.0f); // Ajusta el tamaño del texto

		// Crear un Table para manejar el layout y centrar la Label
		Table table = new Table();
		table.bottom(); // Coloca la label en la parte inferior
		table.setFillParent(true); // El Table ocupará toda la pantalla
		table.add(presEnterLabel).expandX().padBottom(20); // Ajusta el padding y centrado

		// Agregar la Label al Stage
		stage.addActor(table);
	}

	@Override
	public void render(float delta) {
		Render.limpiarPantalla(0, 0, 0);

		b.begin();
		fondo.dibujar();
		b.end();

		// Actualizar el Stage
		stage.act(delta);
		stage.draw();

		procesarEfecto();
	}

	private void procesarEfecto() {
		if (!efectoPantalla) {
			a += 0.01f;
			if (a > 1) {
				a = 1;
				efectoPantalla = true;
			}
		} else {
			contTiempo += 0.05f;
			if (contTiempo > efectoEspera) {
				a -= 0.01f;
				if (a < 0) {
					a = 0;
					efectoPantalla = true;
					termina = true;
				}
			}
		}

		fondo.setTransparencia(a);

		if (termina) {
			contTiempoTermina += 0.1f;
			if (contTiempoTermina > efectoTermina) {
				game.setScreen(new PantallaMenu(game));
			}
		}
	}

	public void terminarPantalla() {
		a = 0;
		efectoPantalla = true;
		termina = true;
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void dispose() {
	}
}
