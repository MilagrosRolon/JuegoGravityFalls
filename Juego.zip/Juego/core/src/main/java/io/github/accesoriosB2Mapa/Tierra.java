
package io.github.accesoriosB2Mapa;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.World;

import io.github.pantallas.PantallaEmpezarBusqueda;

public class Tierra extends objetosInteractivosTiled {
	public Tierra(PantallaEmpezarBusqueda screen, Rectangle bounds) {
		super(screen, bounds);

	}

	@Override
	public void golpeCabeza() {
		// TODO Auto-generated method stub
		
	}
}
