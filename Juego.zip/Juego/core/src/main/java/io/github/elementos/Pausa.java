package io.github.elementos;

import io.github.entradasSalidas.EntradasSalidas;
import io.github.utiles.Config;
import io.github.utiles.Recursos;

public class Pausa {

	private Imagen ventanaPausa;
	private Imagen btnInicio;
	private Imagen btnResume;
	private Imagen btnMusica;

	private int ancho = 350;
	private int alto = 300;
	
	private EntradasSalidas entradas;
	private boolean pausado;
	
	public void mostrarIcono(Imagen iconoPausa) {
		iconoPausa.setSize(60, 60);
		iconoPausa.setPosition(1012, 565);
	}

	public void mostrarVentanaPausa() {
	    ventanaPausa = new Imagen(Recursos.PANTALLAPAUSA);
	    ventanaPausa.setSize(ancho, alto);
	    ventanaPausa.setPosition((Config.ANCHO - ancho) / 2, (Config.ALTO - alto) / 2);

	    btnInicio = new Imagen(Recursos.BTNINICIO);
	    btnInicio.setSize(50, 50);
	    btnInicio.setPosition(ventanaPausa.getX() + 30, ventanaPausa.getY() + 50);

	    btnResume = new Imagen(Recursos.BTNRESUME);
	    btnResume.setSize(50, 50);
	    btnResume.setPosition(ventanaPausa.getX() + 125, ventanaPausa.getY() + 50);

	    btnMusica = new Imagen(Recursos.BTNMUSICA);
	    btnMusica.setSize(50, 50);
	    btnMusica.setPosition(ventanaPausa.getX() + 220, ventanaPausa.getY() + 50);
	}
	
	public void accionarPausa() {
		if(entradas.isClick()){
			if (pausado) {
				if(entradas.getMouseX() >= btnInicio.getX()
						&& entradas.getMouseX() <= btnInicio.getX() + btnInicio.getAncho()
						&& entradas.getMouseY() <= btnInicio.getY() + btnInicio.getAlto()
						&& entradas.getMouseY() <= btnInicio.getY()) {
				}else if(entradas.getMouseX() >= btnResume.getX()
						&& entradas.getMouseX() <= btnResume.getX() + btnResume.getAncho()
						&& entradas.getMouseY() <= btnResume.getY() + btnResume.getAlto()
						&& entradas.getMouseY() <= btnResume.getY()) {
				}else if(entradas.getMouseX() >= btnMusica.getX()
						&& entradas.getMouseX() <= btnMusica.getX() + btnMusica.getAncho()
						&& entradas.getMouseY() <= btnMusica.getY() + btnMusica.getAlto()
						&& entradas.getMouseY() <= btnMusica.getY()) {
				}else {
					pausado = false;
				}
			}else {
				if(entradas.getMouseX() >= btnMusica.getX()
						&& entradas.getMouseX() <= btnMusica.getX() + btnMusica.getAncho()
						&& entradas.getMouseY() <= btnMusica.getY() + btnMusica.getAlto()
						&& entradas.getMouseY() <= btnMusica.getY()) {
					pausado = true;
				}
			}
			entradas.resetInputs();
		}
	}


	public void dibujarPausa() {
		if(pausado)
		{
			ventanaPausa.dibujar();
			btnInicio.dibujar();
			btnResume.dibujar();
			btnMusica.dibujar();
		}else{
		}
	}
}