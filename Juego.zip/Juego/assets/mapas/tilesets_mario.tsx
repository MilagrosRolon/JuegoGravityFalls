<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tilesets_mario" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="2025" columns="45">
 <image source="tilesets_mario.jpeg" width="823" height="823"/>
</tileset>
