<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fondotiled2" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="2769" columns="71">
 <image source="fondotiled2.jpeg" width="1280" height="718"/>
</tileset>
