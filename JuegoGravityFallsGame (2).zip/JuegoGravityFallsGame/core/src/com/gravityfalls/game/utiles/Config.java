package com.gravityfalls.game.utiles;

public class Config {
	
	public static final int ANCHO = 1100;
	public static final int ALTO = 650;

}
