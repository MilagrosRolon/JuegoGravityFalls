package com.gravityfalls.game.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.Escenas.Hud;
import com.gravityfalls.game.accesoriosBox2dMapa.B2BodyTerreno;
import com.gravityfalls.game.elementos.Musica;
import com.gravityfalls.game.sprites.Dipper;
import com.gravityfalls.game.utiles.Recursos;
import com.gravityfalls.game.utiles.Render;

//clase que repesentta el mundo B2d
public class PantallaEmpezarBusqueda implements Screen {
	

	private Array<Body> bodiesToDestroy;

	private GravityFalls game;
	private TextureAtlas atlas;

	private OrthographicCamera gameCam;
	private Viewport gamePort;
	private Hud hud;

	private World world;
	private Box2DDebugRenderer b2Render;

	private Dipper jugador;

	private TmxMapLoader maploader;
	private TiledMap map;
	private OrthogonalTiledMapRenderer renderer;

	private float mapWidth;
	private float mapHeight;

	private Musica sonido;

	private boolean debug = false;

	public PantallaEmpezarBusqueda(GravityFalls game) {
		bodiesToDestroy = new Array<>();


		this.sonido = new Musica(Render.manager);
		try {
			atlas = new TextureAtlas(Gdx.files.internal("dippers_spritesheets/dippers.atlas"));
			System.out.println("Atlas cargado correctamente.");
			// para imprimir los nombres de las regiones y verificar
			for (TextureAtlas.AtlasRegion region : atlas.getRegions()) {
				System.out.println("Región: " + region.name);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error cargando el atlas.");
		}
		this.game = game;

		gameCam = new OrthographicCamera();
		gameCam.zoom = 1.0f;
		gamePort = new FitViewport(GravityFalls.V_WIDTH / GravityFalls.PPM, GravityFalls.V_HEIGHT / GravityFalls.PPM,
				gameCam);
		hud = new Hud(game.batch, game);

		maploader = new TmxMapLoader();
		map = maploader.load(Recursos.MAPA);

		renderer = new OrthogonalTiledMapRenderer(map, 1 / GravityFalls.PPM);

		if (map == null) {
			throw new RuntimeException("Mapa no cargado.");
		}
		if (map.getLayers().getCount() == 0) {
			throw new RuntimeException("No hay capas en el mapa.");
		}

		// Configurar la cámara para que comience en el centro del mapa
		gameCam.position.set(gamePort.getWorldWidth() / 2, gamePort.getWorldHeight() / 2, 0);

		mapWidth = map.getProperties().get("width", Integer.class)
				* map.getProperties().get("tilewidth", Integer.class);
		mapHeight = map.getProperties().get("height", Integer.class)
				* map.getProperties().get("tileheight", Integer.class);

		world = new World(new Vector2(0, -10), true);
		b2Render = new Box2DDebugRenderer();

		new B2BodyTerreno(this);

		jugador = new Dipper(this, game);

	}

	public void marcarCuerpoParaEliminar(Body body) {
	    if (!bodiesToDestroy.contains(body, true)) { // Evita duplicados
	        bodiesToDestroy.add(body);
	    }
	}

	public void eliminarCuerposMarcados() {
	    for (Body body : bodiesToDestroy) {
	        if (body != null) {
	            world.destroyBody(body); // Elimina el cuerpo del mundo físico
	        }
	    }
	    bodiesToDestroy.clear(); // Vacía la lista después de eliminar los cuerpos
	}

	public TextureAtlas getAtlas() {
		return atlas;
	}

	public void gameOver() {
		game.setScreen(new PantallaGameOver(game));
	}

	public void handleInput(float dt) {
		// impulso/velocidad de salto del cuerpo/sprite cuando la tecla esta "prendida"
		if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
			jugador.b2Body.applyLinearImpulse(new Vector2(0, 0.5f), jugador.b2Body.getWorldCenter(), true);
			sonido.generarSonidoSaltar();
		}
		// impulso de la tecla derecha
		if (Gdx.input.isKeyPressed(Input.Keys.RIGHT) && jugador.b2Body.getLinearVelocity().x <= 2) {
			jugador.b2Body.applyLinearImpulse(new Vector2(0.1f, 0), jugador.b2Body.getWorldCenter(), true);
			sonido.generarSonidoCaminar();
		}
		// impulso de la tecla izquierda;
		if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && jugador.b2Body.getLinearVelocity().x >= -2) {
			jugador.b2Body.applyLinearImpulse(new Vector2(-0.1f, 0), jugador.b2Body.getWorldCenter(), true);
			sonido.generarSonidoCaminar();
		}
	}

	public void update(float dt) {
		handleInput(dt);
		jugador.update(dt);
		hud.update(dt);
		world.step(1 / 60f, 6, 2);
		
		  eliminarCuerposMarcados(); 

		// Actualiza posición de la cámara
		gameCam.position.x = Math.max(gameCam.viewportWidth / 2,
				Math.min(jugador.b2Body.getPosition().x, mapWidth - gameCam.viewportWidth / 2));
		gameCam.position.y = Math.max(gameCam.viewportHeight / 2,
				Math.min(jugador.b2Body.getPosition().y, mapHeight - gameCam.viewportHeight / 2));
		gameCam.update();

		// Verifica si el jugador llegó al final del mapa
		if (jugador.b2Body.getPosition().x >= mapWidth - jugador.getWidth() / 2) {
			game.setScreen(new PantallaLevelUp(game));
		}
		renderer.setView(gameCam);
	}

	@Override
	public void show() {

	}

	public void render(float delta) {
		update(delta);

		Render.limpiarPantalla(0, 0, 0);

		renderer.render();
		// para que no se vean las lineas
		if (debug) {
			b2Render.render(world, gameCam.combined);
		}

		game.batch.setProjectionMatrix(gameCam.combined);
		game.batch.begin();
		jugador.draw(game.batch);
		game.batch.end();

		game.batch.setProjectionMatrix(hud.stage.getCamera().combined);
		hud.stage.draw();
	}

	@Override
	public void resize(int width, int height) {
		gamePort.update(width, height);
	}

	public TiledMap getMap() {
		return map;
	}

	public World getWorld() {
		return world;
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void dispose() {
		map.dispose();
		Render.dispose();
		world.dispose();
		b2Render.dispose();
		hud.dispose();
	}
}