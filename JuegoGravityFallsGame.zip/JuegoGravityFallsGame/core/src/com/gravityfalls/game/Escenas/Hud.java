package com.gravityfalls.game.Escenas;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.pantallas.PantallaGameOver;
import com.gravityfalls.game.pantallas.PantallaLevelUp;

public class Hud implements Disposable {

	public Stage stage;
	private Viewport viewport;
	private int worldTimer;
	private float timeCount;
	private static int libro;
	private int vidas;
	private GravityFalls game;

	private Label tiempoRestanteLabel;
	private Label cantVidaLabel;
	private Label tiempoLabel;
	private Label mundoLabel;
	private Label vidasLabel;
	private static Label cantLibroLabel;

	public Hud(SpriteBatch sb, GravityFalls game) {
		this.game = game;
		worldTimer = 30;
		timeCount = 0;
		libro = 0;
		vidas = 3;

		// Configura la cámara y el viewport para el HUD
		viewport = new FitViewport(GravityFalls.V_WIDTH, GravityFalls.V_HEIGHT, new OrthographicCamera());
		stage = new Stage(viewport, sb);

		Table table = new Table();
		table.top();
		table.setFillParent(true);

		tiempoRestanteLabel = new Label(String.format("%03d", worldTimer),
				new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		cantVidaLabel = new Label(String.format("%03d", libro), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		tiempoLabel = new Label("TIEMPO", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		cantLibroLabel = new Label("0",new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		mundoLabel = new Label("LIBROS", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		vidasLabel = new Label("VIDAS", new Label.LabelStyle(new BitmapFont(), Color.WHITE));

		table.add(vidasLabel).expandX().padTop(10);
		table.add(mundoLabel).expandX().padTop(10);
		table.add(tiempoLabel).expandX().padTop(10);
		table.row();
		table.add(cantVidaLabel).expandX().padTop(10);
		table.add(cantLibroLabel).expandX().padTop(10);
		table.add(tiempoRestanteLabel).expandX().padTop(10);

		stage.addActor(table);
	}

	public void update(float deltaTime) {
		timeCount += deltaTime;

		if (timeCount >= 1) {
			worldTimer--;
			tiempoRestanteLabel.setText(String.format("%03d", worldTimer));
			timeCount = 0;
		}

		if (worldTimer <= 0) {
			worldTimer = 0;
			gameOver();
		}

		if (libro == 3) {
			levelUp();
		}
	}

	public void reduceLives() {
		vidas--;
		vidasLabel.setText(String.format("%3d", vidas));
		if (vidas == 0) {
			gameOver();
		}
	}

	public static void addScore(int value) {
		    if (libro < 3) { // incrementa hasta 3
		        libro += value;
		        cantLibroLabel.setText(String.format("%03d", libro)); // Puntaje total
		        cantLibroLabel.setText(String.valueOf(libro)); // Actualiza la cantidad de libros
		    }
		}


	private void levelUp() {
		game.setScreen(new PantallaLevelUp(game));
	}

	private void gameOver() {
		game.setScreen(new PantallaGameOver(game));
	}

	@Override
	public void dispose() {
		stage.dispose();
	}

	public void resize(int width, int height) {
		viewport.update(width, height, true);
	}

	public int getLibros() {

		return libro;
	}

}
