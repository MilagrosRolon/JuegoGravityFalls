package com.gravityfalls.game.Escenas;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.pantallas.PantallaGameOver;
import com.gravityfalls.game.pantallas.PantallaLevelUp;
public class Hud implements Disposable {

	public Stage stage;
	private Viewport viewport;
	private int worldTimer;
	private float timeCount;
	private int libros;
	private int vidas;
	private GravityFalls game;

	Label tiempoRestanteLabel;
	Label librosLabel;
	Label tiempoLabel;
	Label levelLabel;
	Label mundoLabel;
	Label vidasLabel;

	public Hud(SpriteBatch sb, GravityFalls game) {
	    this.game = game;
		worldTimer = 30;
		timeCount = 0;
		libros = 0;
		vidas = 3;

		// Configura la cámara y el viewport para el HUD
		viewport = new FitViewport(GravityFalls.V_WIDTH, GravityFalls.V_HEIGHT, new OrthographicCamera());
		stage = new Stage(viewport, sb);

		Table table = new Table();
		table.top();
		table.setFillParent(true);

		tiempoRestanteLabel = new Label(String.format("%03d", worldTimer),
				new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		librosLabel = new Label(String.format("%03d", libros), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		tiempoLabel = new Label("TIEMPO", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		levelLabel = new Label("1 - 1", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		mundoLabel = new Label("MUNDO", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		vidasLabel = new Label("VIDAS", new Label.LabelStyle(new BitmapFont(), Color.WHITE));

		table.add(vidasLabel).expandX().padTop(10);
		table.add(mundoLabel).expandX().padTop(10);
		table.add(tiempoLabel).expandX().padTop(10);
		table.row();
		table.add(librosLabel).expandX().padTop(10);
		table.add(levelLabel).expandX().padTop(10);
		table.add(tiempoRestanteLabel).expandX().padTop(10);

		stage.addActor(table);
	}

	public void update(int libros, float deltaTime) {
	    this.libros = libros;
	    librosLabel.setText(String.format("%03d", this.libros));

	    timeCount += deltaTime;
	    if (timeCount >= 1) {
	        worldTimer--;
	        tiempoRestanteLabel.setText(String.format("%03d", worldTimer));
	        timeCount = 0;
	    }

	    if (worldTimer <= 0) {
	        worldTimer = 0;
	        gameOver();
	    }

	    if (libros >= 3) {
	        levelUp();
	    }
	}

	public void reduceLives() {
	    vidas--;
	    vidasLabel.setText(String.format("%03d", vidas));
	    if (vidas <= 0) {
	        gameOver();
	    }
	}

	private void levelUp() {
		game.setScreen(new PantallaLevelUp(game)); 
	}

	private void gameOver() {
		game.setScreen(new PantallaGameOver(game));
	}

	@Override
	public void dispose() {
		stage.dispose();
	}

	public void resize(int width, int height) {
	    viewport.update(width, height, true);
	}

	public int getLibros() {
		
		return libros;
	}

}
