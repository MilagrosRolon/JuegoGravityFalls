package com.gravityfalls.game.utiles;

public class Recursos {
	//fondos de las pantallas
	public static final String LOGO  = "fondos/LOGO.png";
	public static final String MENU = "fondos/Fondo.jpg";
	public static final String PERSONAJES =  "fondos/Personajes.jpeg";
	public static final String LEVELUP =  "fondos/LevelUp.png";
	public static final String GAMEOVER =  "fondos/GameOver.png";
	public static final String REGLAS = "fondos/FondoReglas.png";
	public static final String CONTROLES = "fondos/fondoControles.png";
	
	public static final String PANTALLAPAUSA = "fondos/PantallaPausa.png";
	public static final String BTNPAUSA = "elementos/BotonPausa.png";
	public static final String BTNINICIO = "elementos/BotonInicio.png";
	public static final String BTNRESUME = "elementos/BotonResume.png";
	public static final String BTNMUSICA = "elementos/BotonMusica.png";
	
	//TEXTO:
	public static final String FUENTE = "fuentes/MontereyFLF.ttf";
	
	//MAPA:
	public static final String MAPA = "mapas/MapaJuego.tmx"; 
	
	//SPRITES
	public static final String DIPPER = "assets/DIPPER_ITEMS.pack";
	
	//MUSICA:
	public static final String MUSICAPRENDIDA = "elementos/IconoMusicaPrendida.png";
	public static final String MUSICAAPAGADA = "elementos/IconoMusicaApagada.png";
	public static final String MUSICA = "audio/sonidos/MusicaFondo.ogg";
	//SONIDOS:
	public static final String CAMINAR = "audio/sonidos/caminar.wav";
	public static final String SALTAR = "audio/sonidos/saltar.wav";
	
	//PANTALLA COMO JUGAR:
	public static final String FLECHADERECHA = "elementos/FlechaDerecha.png";
	public static final String FLECHAARRIBA = "elementos/FlechaArriba.png";
	public static final String FLECHAIZQUIERDA = "elementos/FlechaIzquierda.png";
}