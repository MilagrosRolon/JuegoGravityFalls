package com.gravityfalls.game.utiles;

public class Config {
	
	public static final int ANCHO = 600;//1100
	public static final int ALTO = 350;//650

}
