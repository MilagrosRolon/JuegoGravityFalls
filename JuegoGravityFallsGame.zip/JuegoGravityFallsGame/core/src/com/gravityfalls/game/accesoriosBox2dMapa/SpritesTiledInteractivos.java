package com.gravityfalls.game.accesoriosBox2dMapa;

import com.badlogic.gdx.physics.box2d.Filter;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTile;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.pantallas.PantallaEmpezarBusqueda;

public abstract class SpritesTiledInteractivos {

	protected World world;
	protected TiledMap map;
	protected TiledMapTile tile;
	protected Rectangle bounds;
	protected Body body;
	protected Fixture fixture;

	public SpritesTiledInteractivos(PantallaEmpezarBusqueda screen, Rectangle bounds) {

		this.world = screen.getWorld();
		this.map = screen.getMap();
		this.bounds = bounds;

		BodyDef bDef = new BodyDef();
		FixtureDef fDef = new FixtureDef();
		PolygonShape shape = new PolygonShape();

		bDef.type = BodyDef.BodyType.StaticBody;
		bDef.position.set((bounds.getX() + bounds.getWidth() / 2) / GravityFalls.PPM,
				(bounds.getY() + bounds.getHeight() / 2) / GravityFalls.PPM);

		body = world.createBody(bDef);

		shape.setAsBox(bounds.getWidth() / 2 / GravityFalls.PPM, bounds.getHeight() / 2 / GravityFalls.PPM);
		fDef.shape = shape;
		
//		body.createFixture(fDef);
		fixture = body.createFixture(fDef);
		body.setUserData(this);
		shape.dispose();
	}


	
	public TiledMapTileLayer.Cell getCell() {
	    TiledMapTileLayer layer = (TiledMapTileLayer) map.getLayers().get(1); // Ajusta el índice si no es la capa correcta
	    int x = (int) (body.getPosition().x * GravityFalls.PPM / layer.getTileWidth());
	    int y = (int) (body.getPosition().y * GravityFalls.PPM / layer.getTileHeight());
	    return layer.getCell(x, y);
	}

	public Body getBody() {
		return body;
	}

}
