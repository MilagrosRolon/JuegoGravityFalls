package com.gravityfalls.game.accesoriosBox2dMapa;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.gravityfalls.game.Escenas.Hud;
import com.gravityfalls.game.pantallas.PantallaEmpezarBusqueda;
import com.gravityfalls.game.sprites.Dipper;
import com.gravityfalls.game.utiles.Recursos;
import com.gravityfalls.game.utiles.Render;

public class Libro extends SpritesTiledInteractivos {

	private TextureRegion libroTexture;
	private boolean isDestroyed = false;

	public Libro(PantallaEmpezarBusqueda screen, Rectangle bounds, String regionName) {
		super(screen, bounds);
	}



}
