package com.gravityfalls.game.accesoriosBox2dMapa;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.World;

public class Libro extends SpritesTiledInteractivos {
	
	private boolean coleccionado;
	
	public Libro(World world, TiledMap map, Rectangle bounds) {
		super(world, map, bounds);
		 coleccionado = false;//inicia  en 0 libros recogidos

	}
	  public boolean isCollected() {
	        return coleccionado;
	    }

	    public void recoger() {
	        coleccionado = true;
	    }
}
