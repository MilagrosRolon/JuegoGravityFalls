package com.gravityfalls.game.accesoriosBox2dMapa;

import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.Escenas.Hud;
import com.gravityfalls.game.pantallas.PantallaLevelUp;
import com.gravityfalls.game.sprites.Dipper;

public class ManejadorDeColisiones implements ContactListener {

	private Hud hud;

	private int librosRecogidos = 0;
	private World world;
	private GravityFalls game;

	public ManejadorDeColisiones(Hud hud, World world, GravityFalls game) {
	    this.hud = hud;
	    this.world = world;
	    this.game = game;
	}


	@Override
	public void beginContact(Contact contacto) {
		Object objetoA = contacto.getFixtureA().getUserData();
		Object objetoB = contacto.getFixtureB().getUserData();

		if (objetoA instanceof Libro && objetoB instanceof Dipper) {
			manejarRecogidaDeLibro((Libro) objetoA);
		} else if (objetoB instanceof Libro && objetoA instanceof Dipper) {
			manejarRecogidaDeLibro((Libro) objetoB);
		}
	}

	private void manejarRecogidaDeLibro(Libro libro) {
		if (!libro.isCollected()) {
			libro.recoger();
			librosRecogidos++;
			hud.update(librosRecogidos, 0); // Actualiza el HUD con el número de libros recogidos

			if (librosRecogidos >= 3) {
				// Cambia la pantalla al nivel siguiente o pantalla de LevelUp
				game.setScreen(new PantallaLevelUp(game));
			}

			world.destroyBody(libro.getBody());
		}
	}

	@Override
	public void endContact(Contact contacto) {

	}

	@Override
	public void preSolve(Contact contacto, Manifold viejoManifold) {

	}

	@Override
	public void postSolve(Contact contacto, ContactImpulse impulso) {

	}
}
