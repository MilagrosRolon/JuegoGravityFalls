package com.gravityfalls.game.accesoriosBox2dMapa;

import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.pantallas.PantallaEmpezarBusqueda;

public class Bill extends Enemy {

	public Bill(PantallaEmpezarBusqueda screen, float x, float y) {
		super(screen, x, y);
		
	}

	@Override
	protected void defineEnemy() {
		  BodyDef bDef = new BodyDef();
		    bDef.position.set(32 / GravityFalls.PPM, 180 / GravityFalls.PPM); // Posición inicial en el mapa
		    bDef.type = BodyDef.BodyType.DynamicBody; // Tipo de cuerpo dinámico
		    bDef.fixedRotation = true; // Evita rotación del cuerpo
		    b2body = world.createBody(bDef); // Crea el cuerpo físico en el mundo

		    // Define la forma del cuerpo
		    PolygonShape shape = new PolygonShape();
		    float width = 12 / GravityFalls.PPM;
		    float height = 26 / GravityFalls.PPM;
		    shape.setAsBox(width / 2, height / 2); // Crea un rectángulo como cuerpo

		    // Define las propiedades físicas del cuerpo
		    FixtureDef fDef = new FixtureDef();
		    fDef.density = 8.0f; // Densidad del cuerpo
		    fDef.friction = 0.4f; // Fricción (para movimientos en el suelo)
		    fDef.restitution = 0.05f; // Elasticidad (rebotes)
		    fDef.shape = shape; // Asocia la forma al fixture
		    b2body.createFixture(fDef); // Crea el fixture en el cuerpo

	}

}
