package com.gravityfalls.game.sprites;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import com.gravityfalls.game.GravityFalls;
import com.gravityfalls.game.pantallas.PantallaEmpezarBusqueda;

public class Dipper extends Sprite {
	public World world;
	public Body b2Body;
	public EstadosDipper estadoActual;
	public EstadosDipper estadoAnterior;
	private Animation<TextureRegion> dipperCorre;
	private Animation<TextureRegion> dipperSalta;
	private TextureRegion dipperParado;
	private float temporizadorEstado;
	private boolean corriendoDerecha;
	private Game game;
	private int librosRecogidos;

	public Dipper(World world, GravityFalls game, PantallaEmpezarBusqueda screen) {
		super();
		this.game = game; // or however you retrieve the GravityFalls instance from screen
		librosRecogidos = 0;
		// Cargar el atlas
		TextureAtlas atlas = screen.getAtlas();
		if (atlas == null) {
			System.out.println("Atlas no encontrado.");
			throw new RuntimeException("No se pudo cargar el atlas.");
		}

		// Inicializar las regiones
		TextureRegion region = atlas.findRegion("dipper_parado-removebg-preview");
		if (region == null) {
			System.out.println("Región 'dipper_parado-removebg-preview' no encontrada.");
			throw new RuntimeException("No se pudo encontrar la región en el atlas.");
		}
		estadoActual = EstadosDipper.PARADO;
		estadoAnterior = EstadosDipper.PARADO;
		temporizadorEstado = 0;
		corriendoDerecha = true;

		// Configura la región y el tamaño del Sprite
		setRegion(region);
		float scaleFactor = 0.20f;
		setBounds(0, 0, (region.getRegionWidth() / GravityFalls.PPM) * scaleFactor,
				(region.getRegionHeight() / GravityFalls.PPM) * scaleFactor);

		this.world = world;
		defineDipper();

		// animaciones
		Array<TextureRegion> frames = new Array<TextureRegion>();
		for (int i = 1; i < 6; i++) {
			frames.add(atlas.findRegion("dipper_camina" + i + "-removebg-preview"));
		}
		dipperCorre = new Animation<>(0.1f, frames);
		frames.clear();
		for (int i = 4; i < 5; i++) {
			frames.add(atlas.findRegion("dipper_salta" + i + "-removebg-preview"));
		}
		dipperSalta = new Animation<>(0.1f, frames);

		dipperParado = atlas.findRegion("dipper_parado-removebg-preview");
	}

	public int getLibros() {
		return librosRecogidos;
	}

	public void update(float dt) {
		setPosition(b2Body.getPosition().x - getWidth() / 2, b2Body.getPosition().y - getHeight() / 2.5f);
		setRegion(getFrame(dt));

		// Verifica si dipper ha caído fuera del área visible
		if (b2Body.getPosition().y < -10 / GravityFalls.PPM) { 
			System.out.println("Game Over!");
			((PantallaEmpezarBusqueda) game.getScreen()).gameOver();
		}
	}

	public TextureRegion getFrame(float dt) {
		estadoActual = getEstado();
		TextureRegion region;

		switch (estadoActual) {
		case SALTANDO:
			region = dipperSalta.getKeyFrame(temporizadorEstado);
			break;
		case CORRIENDO:
			region = dipperCorre.getKeyFrame(temporizadorEstado, true);
			break;
		case CAYENDO:
		case PARADO:
		default:
			region = dipperParado;
			break;
		}

		if ((b2Body.getLinearVelocity().x < 0 || !corriendoDerecha) && !region.isFlipX()) {
			region.flip(true, false);
			corriendoDerecha = true;
		} else if ((b2Body.getLinearVelocity().x > 0 || !corriendoDerecha) && region.isFlipX()) {
			region.flip(true, false);
			corriendoDerecha = true;
		}

		temporizadorEstado = estadoActual == estadoAnterior ? temporizadorEstado + dt : 0;
		estadoAnterior = estadoActual;
		return region;
	}

	public EstadosDipper getEstado() {
		if (b2Body.getLinearVelocity().y > 0
				|| (b2Body.getLinearVelocity().y < 0 && estadoAnterior == EstadosDipper.SALTANDO)) {
			return EstadosDipper.SALTANDO;
		} else if (b2Body.getLinearVelocity().y < 0) {
			return EstadosDipper.CAYENDO;
		} else if (b2Body.getLinearVelocity().y != 0) {
			return EstadosDipper.CORRIENDO;
		} else {
			return EstadosDipper.PARADO;
		}
	}

	public void defineDipper() {
		BodyDef bDef = new BodyDef();
		bDef.position.set(32 / GravityFalls.PPM, 180 / GravityFalls.PPM);// posicion especifica para la caida al mapa
		bDef.type = BodyDef.BodyType.DynamicBody;// establece el tipo de cuerpo
		bDef.fixedRotation = true;// evita la rotacion del cuerpo (rectangulo)
		b2Body = world.createBody(bDef);// crea el rectangulo que contiente al sprite

		PolygonShape shape = new PolygonShape();
		FixtureDef fDef = new FixtureDef();
		float width = 12 / GravityFalls.PPM;
		float height = 26 / GravityFalls.PPM;
		shape.setAsBox(width / 2, height / 2);

		fDef.density = 5.0f;
		fDef.friction = 0.4f;
		fDef.restitution = 0.0f;
		fDef.shape = shape;
		b2Body.createFixture(fDef);
		shape.dispose();
	}
}