package com.gravityfalls.game.sprites;

public enum EstadosDipper {

	CAYENDO, SALTANDO, PARADO, CORRIENDO;
}
