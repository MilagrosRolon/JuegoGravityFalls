<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="DIPPER_ITEMS" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="784" columns="56">
 <image source="DIPPER_ITEMS.png" width="1024" height="256"/>
</tileset>
